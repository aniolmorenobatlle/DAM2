package dam2.amoreno.moreno_aniol_activitat8

import java.io.Serializable

class Students(val foto: Int, var nom: String, val poblacio: String, val email: String, val telefon: String, val dni: String, val repetidor: String): Serializable