package dam2.amoreno.moreno_aniol_activitat9.Classes

import java.io.Serializable

class Students(val foto: Int, var nom: String, val poblacio: String, val hora: String): Serializable