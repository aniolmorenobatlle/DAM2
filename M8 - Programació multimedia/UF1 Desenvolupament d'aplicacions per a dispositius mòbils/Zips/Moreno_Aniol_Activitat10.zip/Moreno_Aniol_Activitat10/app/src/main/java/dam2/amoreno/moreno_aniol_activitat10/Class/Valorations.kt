package dam2.amoreno.moreno_aniol_activitat10.Class

import java.io.Serializable

class Valorations(val nom: String, var opinio: String, val puntuacio: Int): Serializable