package dam2.amoreno.ex2_extra.classes

import java.io.Serializable

class ClassList (val foto: Int, val nom: String, var cognoms: String, val edat: Int, val poblacio: String) : Serializable