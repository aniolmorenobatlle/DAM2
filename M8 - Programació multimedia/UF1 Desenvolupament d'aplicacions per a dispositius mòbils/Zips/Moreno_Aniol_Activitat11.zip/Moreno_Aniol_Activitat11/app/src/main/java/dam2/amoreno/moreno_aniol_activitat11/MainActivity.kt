package dam2.amoreno.moreno_aniol_activitat11

import android.content.Intent
import android.content.SharedPreferences
import android.media.Image
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.net.toUri
import androidx.core.view.get
import dam2.amoreno.moreno_aniol_activitat11.classes.Products

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val marcaProducte = findViewById<Spinner>(R.id.marcaProducte)
        val modelProducte = findViewById<EditText>(R.id.modelProducte)
        val quantitatProducte = findViewById<Spinner>(R.id.quantitatProducte)
        val botoImatge = findViewById<Button>(R.id.botoImatge)
        val imatgeProducte = findViewById<ImageView>(R.id.imatgeProducte)
        val textNoImatge = findViewById<TextView>(R.id.textNoImatge)
        val guardarProducte = findViewById<Button>(R.id.guardarProducte)

        val add = findViewById<ImageView>(R.id.add)
        val list = findViewById<ImageView>(R.id.list)


        if (imatgeProducte.drawable == null) {
            textNoImatge.visibility = View.VISIBLE
            imatgeProducte.visibility = View.GONE
        } else {
            textNoImatge.visibility = View.GONE
            imatgeProducte.visibility = View.VISIBLE
        }


        // Comprova si hi ha una URI d'imatge passada
        val imageUri = intent.getStringExtra("imageUri")
        val imageName = intent.getStringExtra("imageName")
        if (imageUri != null) {
            imatgeProducte.setImageURI(imageUri.toUri())
        }

        marcaProducte.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View?,
                position: Int,
                id: Long
            ) {
                guardarProducte.isEnabled = position != 0
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                guardarProducte.isEnabled = false
            }
        }

        guardarProducte.setOnClickListener {
            val marcaSeleccionada = marcaProducte.selectedItem.toString().lowercase()
            val modelSeleccionat = modelProducte.toString()
            val imageNameSeleccionat = imageName.toString()

            if (marcaSeleccionada != "marca" && modelSeleccionat != null && imageNameSeleccionat != null) {
                val sharedPref: SharedPreferences = getSharedPreferences("shared_$marcaSeleccionada", MODE_PRIVATE)
                val editor = sharedPref.edit()

                val newProduct = Products(
                    marca = marcaSeleccionada,
                    model = modelProducte.text.toString(),
                    quantitat = quantitatProducte.selectedItem.toString(),
                    nomImatge = imageName ?: ""
                )

                editor.putString("marca", newProduct.marca)
                editor.putString("model", newProduct.model)
                editor.putString("quantitat", newProduct.quantitat)
                editor.putString("nomImatge", newProduct.nomImatge)
                editor.apply()
            }
        }

        botoImatge.setOnClickListener {
            val intent = Intent(this, CameraActivity::class.java)
            startActivity(intent)
        }

        add.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        list.setOnClickListener {
            val intent = Intent(this, InvertaryActivity::class.java)
            startActivity(intent)
        }
    }
}