package dam2.amoreno.moreno_aniol_activitat11.classes

data class Products(
    val marca: String,
    val model: String,
    val quantitat: String,
    val nomImatge: String
)
