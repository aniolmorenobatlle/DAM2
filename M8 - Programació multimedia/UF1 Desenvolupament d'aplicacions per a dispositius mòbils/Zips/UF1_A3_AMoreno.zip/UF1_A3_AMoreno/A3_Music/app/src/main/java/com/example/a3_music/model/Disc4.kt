package com.example.a3_music.model

data class Disc4(

    val artist: String,
    val name : String,
    val song : String,
    var year : Int

)
