package com.example.uf1_a6

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.temporal.WeekFields

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)


        val buttonCheck = findViewById<Button>(R.id.buttonCheck)
        val editTextNumber = findViewById<EditText>(R.id.editTextNumber)

        val givenDate = LocalDate.now()

        val weekNumber = givenDate.get(WeekFields.ISO.weekOfWeekBasedYear())

        var isCorrect = false


        buttonCheck.setOnClickListener {
            if (editTextNumber.text.toString() == weekNumber.toString()) {
                isCorrect = true
            } else {
                isCorrect = false
            }

            val intent = Intent(this, ThirdActivity::class.java)
            intent.putExtra("isCorrect", isCorrect)
            startActivity(intent)
        }
    }
}