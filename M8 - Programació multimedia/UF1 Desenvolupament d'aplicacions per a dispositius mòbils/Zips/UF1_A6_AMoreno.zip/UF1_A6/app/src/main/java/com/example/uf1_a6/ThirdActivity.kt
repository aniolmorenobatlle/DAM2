package com.example.uf1_a6

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate
import java.time.temporal.WeekFields

class ThirdActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)

        val textView = findViewById<TextView>(R.id.textViewIsCorrect)
        val buttonCheck = findViewById<Button>(R.id.buttonIsCorrect)

        val isCorrect = intent.getBooleanExtra("isCorrect", false)


        if (isCorrect) {
            textView.text = "Right!!"
            textView.setTextColor(resources.getColor(R.color.green))

            buttonCheck.text = "START AGAIN"

        } else {
            textView.text = "You have failed, try again!!"
            textView.setTextColor(resources.getColor(R.color.red))

            buttonCheck.text = "TRY AGAIN"
        }

        buttonCheck.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

    }
}