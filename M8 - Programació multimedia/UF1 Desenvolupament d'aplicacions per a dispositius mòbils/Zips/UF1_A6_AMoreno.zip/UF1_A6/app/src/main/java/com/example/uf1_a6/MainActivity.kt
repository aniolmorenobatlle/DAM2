package com.example.uf1_a6

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTextUsuari = findViewById<EditText>(R.id.editTextUsuari)
        val editTextPassword = findViewById<EditText>(R.id.editTextPassword)
        val buttonLogin = findViewById<Button>(R.id.buttonLogin)


        buttonLogin.setOnClickListener {

            if (editTextUsuari.text.toString() == "AniolMorenoBatlle2004" && editTextPassword.text.toString() == "AMB2004") {
                val text = "Les dades son correctes!"
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(this, text, duration)
                toast.show()

                val intent = Intent(this, SecondActivity::class.java)
                startActivity(intent)
            }

            if (editTextUsuari.text.toString() == "" ) {
                val text = "El camp usuari no pot estar buit"
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(this, text, duration)
                toast.show()
            } else if (editTextPassword.text.toString() == "") {
                val text = "El camp contrasenya no pot estar buit"
                val duration = Toast.LENGTH_SHORT

                val toast = Toast.makeText(this, text, duration)
                toast.show()
            }

            if (editTextPassword.text.toString().length < 5) {
                val builder: AlertDialog.Builder = AlertDialog.Builder(this)
                builder
                    .setMessage("La contrasenya ha de tenir com a mínim 5 caràcters")
                    .setTitle("Alerta!!")

                val dialog: AlertDialog = builder.create()
                dialog.show()
            }

        }

    }
}