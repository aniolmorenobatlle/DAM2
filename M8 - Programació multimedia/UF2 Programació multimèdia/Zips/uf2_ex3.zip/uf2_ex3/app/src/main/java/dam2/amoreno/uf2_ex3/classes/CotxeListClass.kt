package dam2.amoreno.uf2_ex3.classes

data class CotxeListClass(
    val marca: String,
    val preu: Int,
    val any: Int,
    val lat: Float,
    val long: Float,
)