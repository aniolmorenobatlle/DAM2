package edu.uoc.android.restservice.rest.classes

data class UserListClass(
    val username: String,
    val userImage: String
)
