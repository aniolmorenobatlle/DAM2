package dam2.amoreno.uf2_a3.Classes

class Mapes (

    val id: Int,
    val tipus: String,
    val nom: String,
    val latitud: Double,
    val longitud: Double

)