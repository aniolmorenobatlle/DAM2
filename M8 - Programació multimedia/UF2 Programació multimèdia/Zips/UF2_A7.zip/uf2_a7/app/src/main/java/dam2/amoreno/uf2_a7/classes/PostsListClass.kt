package dam2.amoreno.uf2_a7.classes

data class PostsListClass (
    val avatar: Int,
    val username: String,
    val photo: Int,
    val comment: String,
    val likes: Int,
    val comments: Int,
    val shareds: Int,
    val date: String
)