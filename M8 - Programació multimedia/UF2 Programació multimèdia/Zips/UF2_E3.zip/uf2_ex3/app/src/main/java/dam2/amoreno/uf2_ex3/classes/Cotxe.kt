package dam2.amoreno.uf2_ex3.classes

data class Cotxe(
    val marca: String,
    val model: String,
    val preu: Int,
    val any: Int,
    val long: Float,
    val lat: Float,
    val poblacio: String
)