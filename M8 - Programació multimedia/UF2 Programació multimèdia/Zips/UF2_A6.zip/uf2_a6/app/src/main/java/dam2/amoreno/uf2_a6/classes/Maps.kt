package dam2.amoreno.uf2_a6.classes

data class Maps(
    val address: String,
    val latitud: Float,
    val longitud: Float
)
