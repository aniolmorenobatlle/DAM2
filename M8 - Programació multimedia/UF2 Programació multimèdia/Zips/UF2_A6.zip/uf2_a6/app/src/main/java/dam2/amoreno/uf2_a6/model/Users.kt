package dam2.amoreno.uf2_a6.model

data class Users(
    val username: String? = null,
    val password: String? = null
)