package dam2.amoreno.uf2_a6.classes

data class House(
    val poblation: String,
    val address: String,
    val price: Float,
    val long: Float,
    val lat: Float,
    val imageName: String,
)
