import hashlib


def desxifrar(messgae):

    alf = 'abcirtuv'
    list_alf = list(alf)
    nombres = ['01', '02', '03', '04', '05', '06', '07', '08']

    

    
desxifrar('903706503502903001503708607005')
